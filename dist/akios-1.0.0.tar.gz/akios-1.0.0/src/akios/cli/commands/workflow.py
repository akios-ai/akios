"""
Workflow commands removed for V1.0 to maintain minimal scope.

V1.0 focuses on single workflow execution with direct template usage.
Workflow instances will be considered for V1.1 with proper multi-workflow support.
"""